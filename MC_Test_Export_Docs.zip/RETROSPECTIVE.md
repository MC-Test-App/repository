# RETROSPECTIVE

## Sprintziel
Fragensets aus der MC-Test-App so aufzubereiten, dass sie in Particify und arsnova.click nutzbar sind.

---

## Was lief gut ✅
- Gemeinsames Zielbild war von Anfang an klar: „Exportfähig machen“.
- Datenmodelle beider Plattformen wurden verstanden und dokumentiert.
- Wir haben funktionierende Beispiel-Dateien (JSON und CSV) erzeugt, die importierbar sind.
- Die Mapping-Tabelle (MC-Test → Zielplattform) reduziert Missverständnisse in der Entwicklung.

---

## Was war schwierig ⚠️
- Unterschiedliche Modelllogik: Particify unterstützt mehrere korrekte Antworten, arsnova.click erwartet genau eine richtige Antwort → Konfliktfall.
- Zeitlimit ist bei arsnova.click Pflicht, aber nicht in allen bestehenden MC-Test-Fragen vorhanden.
- Keine offiziell dokumentierte Massenimport-UI bei Particify → wir müssen davon ausgehen, dass Lehrkräfte den Export als Vorlage manuell übertragen oder dass später eine API-Anbindung kommt.

---

## Learnings 💡
- Wir brauchen im Export einen „Default-Zeitlimit“-Wert.
- Wir müssen dem/der Lehrkraft anzeigen, wenn wir mehrere richtige Antworten auf nur eine reduzieren (Transparenz).
- JSON ist für beide Plattformen die stabilste Basis. CSV ist ein Komfort-Bonus für arsnova.click.

---

## Konkrete nächste Schritte 🚀
1. Validierungskomponente bauen (Pflichtfelder prüfen, Warnungen sammeln).
2. UI für Exportdialog implementieren.
3. Tooltips/Hinweise schreiben („So importierst du die Datei in arsnova.click“).
4. API-Upload für Particify evaluieren (nächster Sprint).
