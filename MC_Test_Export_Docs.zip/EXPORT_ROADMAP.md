# EXPORT_ROADMAP

## Ziel
Plan für die Umsetzung des Export-Features für Particify und arsnova.click.

---

## Phase 1: Analyse (abgeschlossen)
- Plattformen identifiziert
- Zielformate dokumentiert
- Beispiel-Fragensets manuell konvertiert
- Risiken bewertet (Mehrfachlösungen vs. Einzellösung)

Output dieser Phase:
- MARKTANALYSE_Plattformen.md
- TECH_SPEC_Plattformen.md

---

## Phase 2: Implementierung (laufend)
- UI: Export-Dialog in der MC-Test-App
- Logik: Mapping der MC-Test-Fragen auf Zielfelder
- Generatoren:
  - ParticifyJSONExporter
  - ArsnovaJSONExporter
  - ArsnovaCSVExporter
- Validierung: Pflichtfelder prüfen

Deliverables dieser Phase:
- FEATURE_SPEC_EXPORT.md
- export-examples/

---

## Phase 3: Test & Qualitätssicherung
- Test mit echten Fragensets aus Unterricht
- CSV-Import-Test in arsnova.click
- JSON-Strukturtest gegen Particify
- Prüfen von Umlauten / Sonderzeichen

Deliverable dieser Phase:
- RETROSPECTIVE.md (Erkenntnisse festhalten)

---

## Phase 4: Rollout
- Export-Feature an Nutzer:innen ausrollen
- Kurzanleitung für Lehrkräfte schreiben
- Feedback sammeln für nächsten Sprint

Nächster Sprint (Ausblick):
- Optionaler direkter Upload an Particify via API
- Kategorien / Themenblöcke übernehmen
