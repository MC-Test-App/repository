# MARKTANALYSE_Plattformen

## Ziel
Ziel der Analyse ist es, die beiden Zielplattformen **Particify** und **arsnova.click** im Hinblick auf den Import von Fragensets zu vergleichen und ihre Anforderungen, Möglichkeiten und Grenzen zu verstehen.

---

## 1. Particify
### Beschreibung
Particify (ars.particify.de) ist eine interaktive Lernplattform, die Umfragen, Quizzes, Brainstormings, Live-Feedback und Q&A-Sessions ermöglicht. Sie ist datenschutzfreundlich, Open-Source-orientiert und wird häufig in Schule und Hochschule genutzt.

### Stärken
- Moderne Benutzeroberfläche und Präsentationsmodus
- Flexible Fragetypen (Multiple Choice, Freitext, Skala, Wordcloud, etc.)
- Echtzeit-Feedback und anonyme Teilnahme ohne Login
- Möglichkeit zur Automatisierung über strukturierte JSON-Daten (API-Ansatz)

### Schwächen
- Kein klar sichtbarer Bulk-Import im normalen UI
- Aktuell eher für Live-Session-Moderation gedacht als für klassische Prüfungs-Archive
- Dokumentation der Importschnittstelle nicht prominent in der Oberfläche

### Importanforderungen (Zielannahme für Export)
- Format: JSON (strukturierte Fragen, Antwortoptionen, Markierung der richtigen Lösung)
- Pflichtfelder pro Frage:
  - `type` (z. B. "multiple-choice")
  - `question` (Fragetext)
  - `options` (Antwortmöglichkeiten)
  - `correctAnswers` (eine oder mehrere korrekte Antworten)
- Keine eingebetteten Bilder/Audio vorgesehen im Basismodell

---

## 2. arsnova.click
### Beschreibung
arsnova.click ist eine Quizplattform für Unterricht und Schulungen. Sie funktioniert ähnlich wie Kahoot, aber werbefrei, datenschutzkonform und für Schulen geeignet. Man kann live spielen, ohne dass sich die Schüler:innen registrieren müssen.

### Stärken
- Sehr schneller Einstieg (ein Quizname reicht zum Mitspielen)
- CSV- oder JSON-Import möglich über „Quiz-Import“ in der Oberfläche
- Punkte-/Gamification-Ansatz für Motivation
- Klare Struktur für Multiple-Choice-Fragen
- Funktioniert gut offline vorbereitet → online abgespielt

### Schwächen
- Weniger unterschiedliche Fragetypen als Particify
- Stärker auf Quiz / Wettbewerb ausgelegt, weniger auf Diskussion
- Zeitlimit ist verpflichtend beim Quizflow

### Importanforderungen
- Formate: JSON oder CSV
- Pflichtfelder pro Frage:
  - `questionText`
  - `answers[]` (Liste mit Antwortmöglichkeiten)
  - `correctAnswer` (richtige Antwort als Text)
  - `timeLimit` (in Sekunden)
- Kodierung: UTF-8

---

## 3. Vergleich

| Kriterium                         | Particify                         | arsnova.click                       |
|----------------------------------|-----------------------------------|-------------------------------------|
| Open Source / Schuleignung       | ✅ sehr gut                        | ✅ sehr gut                          |
| Anonyme Teilnahme                | ✅                                | ✅                                  |
| Fokus                             | Interaktion + Feedback            | Quiz / Wissen abprüfen              |
| JSON-Import möglich              | ✅ (technisch über Struktur)      | ✅ (direkt)                          |
| CSV-Import                        | ❌                                | ✅                                  |
| Bulk-Import über UI              | eher nein                         | ja (Quiz-Import)                    |
| Fragetypen-Vielfalt              | hoch (MC, Skala, Freitext …)      | mittel (MC, Wahr/Falsch …)          |
| Zeitlimit pro Frage              | optional                          | fester Bestandteil                  |
| Punkte-/Gamification             | eher gering                       | hoch                                |
| Eignet sich für Prüfungs-Export  | gut                               | sehr gut                            |

---

## 4. Fazit
Beide Plattformen sind sinnvolle Ziele für den Export aus der MC-Test-App.

**arsnova.click** ist ideal für Lehrkräfte, die ein fertiges Quiz per CSV/JSON importieren und sofort im Unterricht „spielen“ wollen.  
**Particify** ist stärker für Live-Unterrichtssituationen gedacht, in denen nicht nur abgefragt wird, sondern auch Feedback gesammelt wird und Fragen diskutiert werden.

Für uns bedeutet das:  
Wir müssen **zwei Exportpfade** unterstützen – einen Particify-kompatiblen JSON-Export und einen arsnova.click-kompatiblen JSON/CSV-Export.
