# TECH_SPEC_Plattformen

## Ziel
Technische Dokumentation der Zielformate für den Export von MC-Test-Fragensets in Particify und arsnova.click.  
Diese Spezifikation definiert die Datenfelder, die Konvertierungslogik und die technischen Anforderungen.

---

## 1. Particify – Zielformat (JSON)
### Struktur
```json
{
  "questions": [
    {
      "type": "multiple-choice",
      "question": "Wie viele Planeten hat unser Sonnensystem?",
      "options": ["7", "8", "9", "10"],
      "correctAnswers": ["8"]
    }
  ]
}
```

### Felddefinitionen
- `questions`: Array aller Fragen
- `type`:
  - mögliche Werte: `multiple-choice`, `free-text`, `scale`
  - wir exportieren aktuell nur `multiple-choice`
- `question`: Fragetext (String)
- `options`: Liste aller Antwortmöglichkeiten (Array von Strings)
- `correctAnswers`: Liste der korrekten Antwortoptionen (Array von Strings)

### Technische Anforderungen
- Encoding: UTF-8
- Maximal unterstützter Zeichensatz: Unicode ohne Emojis ist sicher; Emojis testen
- Transportvarianten:
  - Download als `.json`
  - (später) POST gegen Particify-API-Endpunkt

---

## 2. arsnova.click – Zielformat
### Variante A: JSON
```json
{
  "quiz": {
    "title": "Astronomie-Test",
    "questions": [
      {
        "questionText": "Wie heißt der größte Planet?",
        "answers": ["Erde", "Jupiter", "Saturn", "Neptun"],
        "correctAnswer": "Jupiter",
        "timeLimit": 30
      }
    ]
  }
}
```

#### Felddefinitionen
- `quiz.title`: Titel des Quizzes
- `quiz.questions`: Array
  - `questionText`: Fragetext
  - `answers`: Liste aller Antwortmöglichkeiten
  - `correctAnswer`: genau eine richtige Antwort (String)
  - `timeLimit`: Antwortzeit in Sekunden (Integer)

### Variante B: CSV
CSV-Spalten (Header):
- `questionText`
- `answers` (Antwortoptionen durch `;` getrennt)
- `correctAnswer`
- `timeLimit`

Beispielzeile (eine Frage):
```csv
"Was ist die Hauptstadt von Frankreich?","Berlin;Madrid;Paris;Rom","Paris",30
```

---

## 3. Mapping MC-Test → Zielplattformen

| MC-Test Feld         | Particify Feld        | arsnova.click Feld   |
|----------------------|-----------------------|----------------------|
| Frage (Text)         | question              | questionText         |
| Antwortoptionen[]    | options[]             | answers[]            |
| Richtige Antwort(en) | correctAnswers[]      | correctAnswer        |
| Zeitlimit            | (optional / none)     | timeLimit            |
| Kategorie/Thema      | (kann ignoriert werden oder als Meta) | quiz.title (optional) |

Annahme: MC-Test erlaubt mehrere richtige Antworten.  
arsnova.click erlaubt nur **eine** richtige Antwort → bei mehreren richtigen Antworten wird die erste genommen, Rest verworfen (mit Warnung).

---

## 4. Validierung
Bei jedem Export führen wir eine Prüfung durch:
1. Jede Frage muss mindestens **2 Antwortoptionen** haben.
2. Es muss **mindestens eine richtige Antwort** geben.
3. In arsnova.click darf die richtige Antwort **genau einer** der Antworttexte sein.
4. TimeLimit: Falls in MC-Test keines gesetzt ist, Standardwert = 30 Sekunden.

---

## 5. UI-/Technik-Folgen
- Wir brauchen einen Export-Dialog in der MC-Test-App mit:
  - Auswahl „Particify JSON“ oder „arsnova.click JSON/CSV“
  - Eingabe Quiz-Titel (für arsnova.click)
  - Vorschau
  - „Export jetzt herunterladen“-Button
