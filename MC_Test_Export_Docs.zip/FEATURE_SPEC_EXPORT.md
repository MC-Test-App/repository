# FEATURE_SPEC_EXPORT

## Ziel
Diese Spezifikation beschreibt das neue Export-Feature in der MC-Test-App.  
Lehrkräfte/Dozierende sollen Fragensets so exportieren können, dass sie direkt in Particify oder arsnova.click nutzbar sind.

---

## 1. User Story
Als Lehrkraft möchte ich meine vorhandenen MC-Test-Fragen in ein Format exportieren, das ich sofort in Particify oder arsnova.click einsetzen kann, ohne jede Frage neu abzutippen.

---

## 2. Hauptfunktionen
1. **Zielplattform auswählen**
   - Optionen: `Particify`, `arsnova.click`
2. **Exportformat wählen**
   - Particify → JSON
   - arsnova.click → JSON oder CSV
3. **Metadaten setzen**
   - Quiz-Titel (für arsnova.click Pflicht, für Particify optional)
   - Standard-Zeitlimit (z. B. 30 Sekunden)
4. **Vorschau anzeigen**
   - Gerenderte Zieldatei zeigen, bevor gespeichert wird
5. **Datei speichern**
   - Download auf Gerät als `.json` oder `.csv`
6. **Validierung**
   - Warnung, wenn eine Frage mehrere korrekte Antworten hat, aber arsnova.click nur eine erlaubt
   - Warnung bei leeren Antwortfeldern

---

## 3. Erweiterte Funktionen
- Automatische Normalisierung der Antworten (Trimmen von Leerzeichen)
- Entfernen von Duplikat-Antworten
- Fallback für fehlendes Zeitlimit → Default 30s
- Logging von Exportergebnissen (für spätere Fehleranalyse)

---

## 4. Beispielablauf (Click-Flow)
1. Nutzer öffnet ein Fragenset in der MC-Test-App.
2. Klick auf `Exportieren`.
3. Dialog öffnet sich:
   - Auswahl Zielplattform
   - ggf. Titel eingeben
   - Vorschau
4. Klick `Herunterladen`.
5. Datei landet lokal auf dem Gerät und kann direkt in Particify / arsnova.click importiert werden.

---

## 5. Nicht-Ziele (Out of Scope für diesen Sprint)
- Kein automatischer Upload direkt in Particify oder arsnova.click (nur Download)
- Keine Bild-/Audio-Fragen
- Keine freien Textfragen, Fokus ist Multiple Choice
